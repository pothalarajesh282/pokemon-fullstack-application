const NodeRSA = require('node-rsa');
const fs = require('fs');

// Load keys from files
const publicKey = fs.readFileSync('public.pem', 'utf8');
const privateKey = fs.readFileSync('private.pem', 'utf8');

// Create RSA key objects
const key = new NodeRSA();
key.importKey(publicKey, 'public');
const privateKeyObj = new NodeRSA();
privateKeyObj.importKey(privateKey, 'private');

// Encrypt data
const data = 'This is a secret message.';
const encryptedData = key.encrypt(data, 'base64');
console.log('Encrypted Data:', encryptedData);

// Decrypt data
const decryptedData = privateKeyObj.decrypt(encryptedData, 'utf8');
console.log('Decrypted Data:', decryptedData);
