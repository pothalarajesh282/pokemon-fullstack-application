const config = {
    baseUrl: "https://server-plum-seven.vercel.app",
  };
  
  export default config;
  